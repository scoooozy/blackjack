import "./App.css";
import { useCallback, useEffect, useState } from "react";
import CardPlacement from "./components/CardPlacement";
import { CardType, GameState, getCardsSum, getRandomCard } from "./utils";
import CardPlacementDealer from "./components/CardPlacementDealer";
import Nav from "./components/Nav";



const defaultPlayerCards = [GameState.NONE, GameState.NONE, GameState.NONE];
const defaultPlayerBets = [0, 0, 0];
function App() {
    const [cards, setCards] = useState<CardType[][]>([]);
    const [turn, setTurn] = useState(1);
    const [game, setGame] = useState(true);
    const [onBet, setOnBet] = useState(true);
    const [playerCardsState, setPlayerCardsState] =
        useState<GameState[]>(defaultPlayerCards);
    const [playerCardsBets, setPlayerCardsBets] =
        useState<number[]>(defaultPlayerBets);
    const [points, setPoints] = useState(1000);
    const [currentBet, setCurrentBet] = useState(0);

    const restartGame = () => {
        console.log("RESTARTING THE GAME");
        setCards([]);
        setTurn(1);
        setGame(true);
        setPlayerCardsState([...defaultPlayerCards]);
    };
    const updateGameState = useCallback(() => {
        console.log("UPDATING THE GAME STATE");
        const cardsSum = cards.map(
            (cardPlacement) => getCardsSum(cardPlacement)[0]
        );
        const dealerSum = cardsSum[0];
        let playerGameState: GameState[];
        if (dealerSum > 21) {
            playerGameState = cardsSum.slice(1).map((sum) => {
                if (sum > 21) return GameState.LOST;
                else return GameState.VICTORY;
            });
        } else {
            playerGameState = cardsSum.slice(1).map((sum) => {
                if (sum == 21) return GameState.VICTORY;
                else if (sum < dealerSum || sum > 21) return GameState.LOST;
                else if (sum == dealerSum) return GameState.PUSH;
                else return GameState.VICTORY;
            });
        }

        setPlayerCardsState([...playerGameState]);
        const amounts = playerGameState.map((state, index) => {
            if (state === GameState.VICTORY) {
                console.log("COUNTING AS VICTORY");
                return playerCardsBets[index] * 2;
            } else if (state === GameState.PUSH) {
                console.log("COUNTING AS PUSH");
                return playerCardsBets[index];
            }
            console.log("COUNTING AS LOST");
            return 0;
        });
        setPoints(
            (old) => old + amounts.reduce((prev, curr) => prev + curr, 0)
        );
        console.log(playerCardsBets);
        setPlayerCardsBets([0, 0, 0, 0]);
        setOnBet(true);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cards]);

    useEffect(() => {
        if (!onBet && !game) {
            updateGameState();
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [onBet, game]);

    const dealCards = () => {
        setOnBet(false);
        let i = 0;
        let rounds = 0;
        const interval = setInterval(() => {
            hit(i);
            i++;
            if (i == 4) {
                i = 0;
                rounds++;
                if (rounds > 1) {
                    clearInterval(interval);
                }
            }
        }, 300);
    };

    const hit = (index: number) => {
        const card = getRandomCard();
        setCards((prev) => {
            let temp;
            if (!prev[index]) {
                temp = [card];
            } else {
                temp = [...prev[index], card];
            }
            return [...prev.slice(0, index), temp, ...prev.slice(index + 1)];
        });
    };

    const stand = (index: number) => {
        setTurn(index + 1 >= cards.length ? 0 : index + 1);
    };

    const addBetToHand = (index: number) => {
        if (points >= currentBet) {
            const bets = [...playerCardsBets];
            setPoints((old) => old - currentBet);
            bets[index] += currentBet;
            setPlayerCardsBets(bets);
        }
    };

    return (
        <div className="h-screen  overflow-hidden" id="game">
            <Nav />
            <div className="grid grid-cols-3 p-2 grid-rows-3 place-items-center">
                <CardPlacementDealer
                    turn={turn == 0}
                    cards={cards[0]}
                    className="col-start-2"
                    hit={() => hit(0)}
                    end={() => setGame(false)}
                />
                <CardPlacement
                    bet={playerCardsBets[0]}
                    state={playerCardsState[0]}
                    turn={turn == 1 && !onBet}
                    stand={() => stand(1)}
                    cards={cards[1]}
                    className="col-start-1"
                    addBetToHand={() => onBet && addBetToHand(0)}
                />
                <CardPlacement
                    bet={playerCardsBets[1]}
                    state={playerCardsState[1]}
                    stand={() => stand(2)}
                    turn={turn == 2 && !onBet}
                    cards={cards[2]}
                    className="row-start-3 col-start-2"
                    addBetToHand={() => onBet && addBetToHand(1)}
                />
                <CardPlacement
                    bet={playerCardsBets[2]}
                    state={playerCardsState[2]}
                    turn={turn == 3 && !onBet}
                    stand={() => stand(3)}
                    cards={cards[3]}
                    className="col-start-3 "
                    addBetToHand={() => onBet && addBetToHand(2)}
                />
            </div>

            <div className="game-panel">
                <button
                    onClick={dealCards}
                    disabled={cards.length > 0}
                    className="btn-black"
                >
                    Deal
                </button>
                <button
                    onClick={restartGame}
                    disabled={game}
                    className="btn-black"
                >
                    Restart
                </button>
                <p className=" border p-2 text-black">Balance:{points}pt</p>

                {onBet && (
                    <div className="flex items-center justify-center gap-2">
                        <button
                            onClick={() => setCurrentBet((old) => old - 25)}
                            disabled={points === 0 || currentBet === 0}
                            className="btn-black"
                        >
                            -
                        </button>
                        <p className="text-black">{currentBet}</p>
                        <button
                            disabled={points === 0 || currentBet === points}
                            onClick={() => setCurrentBet((old) => old + 25)}
                            className="btn-black bg-red-500"
                        >
                            +
                        </button>
                    </div>
                )}

                <div className="flex gap-2">
                    <button
                        disabled={!cards || cards.length < 2}
                        onClick={() => {
                            hit(turn);
                        }}
                        className="btn-black bg-red-500"
                    >
                        Hit
                    </button>
                    <button
                        disabled={!cards || cards.length < 2}
                        onClick={() => stand(turn)}
                        className="btn-black bg-red-500"

                    >
                        Stand
                    </button>
                </div>

            </div>
        </div>
    );
}

export default App;
